export interface Project {
  title: string;
  description: string;
  imageUrl: string;
  url: string;
  inProgress?: boolean;
}
